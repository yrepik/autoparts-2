<?php
// Heading
$_['heading_title']  = 'Blad Nie Gevind Nie!';

// Text
$_['text_not_found'] = 'Die bladsy wat u soek, kon nie gevind word nie! Kontak asseblief u administrateur indien die probleem voortduur.';
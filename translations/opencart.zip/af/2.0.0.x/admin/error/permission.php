<?php
// Heading
$_['heading_title']   = 'Reg Verbied!';

// Text
$_['text_permission'] = 'U het nie toestemming om hierdie bladsy te bekom, verwys asseblief na u stelsel administrateur.';
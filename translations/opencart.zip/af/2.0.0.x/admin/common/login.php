<?php
// header
$_['heading_title']  = 'Administrasie';

// Text
$_['text_heading']   = 'Administrasie';
$_['text_login']     = 'Tik asseblief u in teken besonderhede.';
$_['text_forgotten'] = 'Vergete  Wagwoord';

// Entry
$_['entry_username'] = 'Gebruikersnaam';
$_['entry_password'] = 'Wagwoord';

// Button
$_['button_login']   = 'Aantekening';

// Error
$_['error_login']    = 'Geen passing vir Gebruikersnaam en/of Wagwoord.';
$_['error_token']    = 'Ongeldige teken sessie. Teken asseblief weer in.';
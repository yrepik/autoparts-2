<?php
// Heading
$_['heading_title']                = 'Kontroleskerm';

// Text
$_['text_order_total']             = 'Totale Bestellings';
$_['text_customer_total']          = 'Totale Kliënte';
$_['text_sale_total']              = 'Totale Verkope';
$_['text_online_total']            = 'Mense Aanlyn';
$_['text_map']                     = 'Wêreld Kaart';
$_['text_sale']                    = 'Verkoop Analise';
$_['text_activity']                = 'Onlangse Aktiwiteit';
$_['text_recent']                  = 'Nuutste Bestellings';
$_['text_order']                   = 'Bestellings';
$_['text_customer']                = 'Kliënte';
$_['text_day']                     = 'Vandag';
$_['text_week']                    = 'Week';
$_['text_month']                   = 'Maand';
$_['text_year']                    = 'Jaar';
$_['text_view']                    = 'Wys meer...';

// Error
$_['error_install']                = 'Waarskuwing: Installeer gids bestaan steeds en moet verwyder word vir sekuriteit redes!';
<?php
// header
$_['heading_title']  = 'Herstel u wagwoord';

// Text
$_['text_reset']     = 'Herstel u wagwoord!';
$_['text_password']  = 'Tik die nuwe wagwoord wat u wil gebruik.';
$_['text_success']   = 'Sukses: U wagwoord is suksesvol opgedateer.';

// Entry
$_['entry_password'] = 'Wagwoord';
$_['entry_confirm']  = 'Bevestig';

// Error
$_['error_password'] = 'Wagwoord moet tussen 5 en 20 karakters wees!';
$_['error_confirm']  = 'Wagwoord en wagwoord bevestiging stem nie ooreen nie!';
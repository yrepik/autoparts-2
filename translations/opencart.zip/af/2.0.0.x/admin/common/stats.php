<?php
$_['text_complete_status']   = 'Bestellings Voltooi'; 
$_['text_processing_status'] = 'Bestellings Verwerk'; 
$_['text_other_status']      = 'Ander Statusse'; 
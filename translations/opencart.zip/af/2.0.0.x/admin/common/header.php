<?php
// Heading
$_['heading_title']        = 'OpenCart';

// Text
$_['text_order']           = 'Bestellings';
$_['text_order_status']    = 'Hangende';
$_['text_complete_status'] = 'Voltooide';
$_['text_customer']        = 'Kliënte';
$_['text_online']          = 'Kliënte Aanlyn';
$_['text_approval']        = 'Hangende Goedkeuring';
$_['text_product']         = 'Produkte';
$_['text_stock']           = 'Uit Voorraad';
$_['text_review']          = 'Resensies';
$_['text_return']          = 'Tergukeer';
$_['text_affiliate']       = 'Affiliasies';
$_['text_store']           = 'Winkels';
$_['text_front']           = 'Winkel Voorgevel';
$_['text_help']            = 'Hulp';
$_['text_homepage']        = 'Tuisblad';
$_['text_support']         = 'Ondersteuning Forums';
$_['text_documentation']   = 'Dokumentasie';
$_['text_logout']          = 'Uitteken';
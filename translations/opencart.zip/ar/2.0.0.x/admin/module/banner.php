<?php
// Heading
$_['heading_title']    = 'ترويسة';

// Text
$_['text_module']      = 'موديول';
$_['text_success']     = 'لقد عدلت ترويسة المديول بنجاح';
$_['text_edit']        = 'تعديل ترويسة المديول';

// Entry
$_['entry_banner']     = 'ترويسة';
$_['entry_dimension']  = 'الأبعاد ( العرص * الطول) ونوع إعادة ضبط الحجم';
$_['entry_width']      = 'العرض';
$_['entry_height']     = 'الارتفاع';
$_['entry_status']     = 'الحالة';

// Error
$_['error_permission'] = 'تحذير: ليس لديك الصلاحية لتعديل ترويسة المديول !';
$_['error_module']     = 'تحذير: المديول مطلوب !';
$_['error_dimension']  = 'العرض  &amp: الارتفاع مطلوب !';
